/opt/mapr/flume/flume-1.6.0/bin/flume-ng agent --conf conf --conf-file kafka-flume.conf --name tier1 -Dflume.root.logger=INFO,console

